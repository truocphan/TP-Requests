class TP_MQTT_REQUEST:
	def __init__(self):
		print("TP_MQTT_REQUEST")