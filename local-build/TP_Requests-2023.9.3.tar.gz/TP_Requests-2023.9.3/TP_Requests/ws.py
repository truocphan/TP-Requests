class TP_WEBSOCKET_REQUEST:
	def __init__(self):
		print("TP_WEBSOCKET_REQUEST")